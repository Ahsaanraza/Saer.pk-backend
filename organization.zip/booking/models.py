from django.db import models
from django.contrib.auth.models import User
from organization.models import Organization, Branch, Agency
from packages.models import TransportSectorPrice, City, Shirka

# Create your models here.


class Bank(models.Model):
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    account_title = models.CharField(max_length=100)
    account_number = models.TextField(blank=True, null=True)
    iban = models.CharField(max_length=50, blank=True, null=True)

    def __str__(self):
        return f"{self.name} - {self.branch_code}"


class Booking(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="bookings")
    organization = models.ForeignKey(
        Organization, on_delete=models.CASCADE, related_name="bookings"
    )
    branch = models.ForeignKey(
        Branch, on_delete=models.CASCADE, related_name="bookings"
    )
    agency = models.ForeignKey(
        Agency, on_delete=models.CASCADE, related_name="bookings"
    )
    booking_number = models.CharField(max_length=20)
    date = models.DateTimeField(auto_now_add=True)
    expiry_time= models.DateTimeField(blank=True, null=True)
    total_pax = models.IntegerField(default=0)
    total_adult = models.IntegerField(default=0)
    total_infant = models.IntegerField(default=0)
    total_child = models.IntegerField(default=0)
    total_ticket_amount = models.FloatField(default=0)
    total_hotel_amount = models.FloatField(default=0)
    total_transport_amount = models.FloatField(default=0)
    total_visa_amount = models.FloatField(default=0)
    total_amount = models.FloatField(default=0)
    is_paid = models.BooleanField(default=False)
    status = models.CharField(max_length=20)
    payment_status = models.CharField(max_length=20, default="Pending")
    is_partial_payment_allowed = models.BooleanField(default=False)
    category = models.CharField(max_length=20,blank=True, null=True) 
    


class BookingHotelDetails(models.Model):
    booking = models.ForeignKey(
        Booking, on_delete=models.CASCADE, related_name="hotel_details"
    )
    hotel = models.ForeignKey("tickets.Hotels", on_delete=models.PROTECT)
    check_in_time = models.DateField(blank=True, null=True)
    check_out_time = models.DateField(blank=True, null=True)
    number_of_nights = models.IntegerField(default=0)
    room_type = models.CharField(max_length=20, blank=True, null=True)
    price = models.FloatField(default=0)
    quantity = models.FloatField(default=0)
    total_price = models.FloatField(default=0)
    riyal_rate = models.FloatField(default=0)
    is_price_pkr= models.BooleanField(default=True)


class BookingTransportDetails(models.Model):
    booking = models.ForeignKey(
        Booking, on_delete=models.CASCADE, related_name="transport_details"
    )
    transport_sector = models.ForeignKey(TransportSectorPrice, on_delete=models.PROTECT)
    shirka= models.ForeignKey(Shirka, on_delete=models.PROTECT, blank=True, null=True)
    vehicle_type = models.CharField(max_length=50)
    price = models.FloatField(default=0)
    total_price = models.FloatField(default=0)
    is_price_pkr= models.BooleanField(default=True)
    riyal_rate = models.FloatField(default=0)


class BookingTicketDetails(models.Model):
    booking = models.ForeignKey(
        Booking, on_delete=models.CASCADE, related_name="ticket_details"
    )
    ticket = models.ForeignKey("tickets.Ticket", on_delete=models.PROTECT)
    is_meal_included = models.BooleanField(default=False)
    is_refundable = models.BooleanField(default=False)
    pnr = models.CharField(max_length=100)
    child_price = models.FloatField(default=0)
    infant_price = models.FloatField(default=0)
    adult_price = models.FloatField(default=0)
    seats = models.IntegerField(default=0)
    weight = models.FloatField(default=0)
    pieces = models.IntegerField(default=0)
    is_umrah_seat = models.BooleanField(default=False)
    trip_type = models.CharField(max_length=50)
    departure_stay_type = models.CharField(max_length=50)
    return_stay_type = models.CharField(max_length=50)
    status = models.CharField(max_length=50, blank=True, null=True)
    is_price_pkr= models.BooleanField(default=True)
    riyal_rate = models.FloatField(default=0)


class BookingTicketTicketTripDetails(models.Model):
    ticket = models.ForeignKey(
        BookingTicketDetails, on_delete=models.CASCADE, related_name="trip_details"
    )
    departure_date_time = models.DateTimeField()
    arrival_date_time = models.DateTimeField()
    departure_city = models.ForeignKey(
        City, on_delete=models.CASCADE, related_name="booking_departure_city"
    )
    arrival_city = models.ForeignKey(
        City, on_delete=models.CASCADE, related_name="booking_arrival_city"
    )
    trip_type = models.CharField(max_length=50)


class BookingTicketStopoverDetails(models.Model):
    ticket = models.ForeignKey(
        BookingTicketDetails, on_delete=models.CASCADE, related_name="stopover_details"
    )
    stopover_city = models.ForeignKey(
        City,
        on_delete=models.CASCADE,
    )
    stopover_duration = models.CharField(max_length=100)
    trip_type = models.CharField(max_length=50)


class BookingPersonDetail(models.Model):
    booking = models.ForeignKey(
        Booking, on_delete=models.CASCADE, related_name="person_details"
    )
    age_group = models.CharField(max_length=20, blank=True, null=True)
    person_title = models.CharField(max_length=10, blank=True, null=True)
    first_name = models.CharField(max_length=30, blank=True, null=True)
    last_name = models.CharField(max_length=30, blank=True, null=True)
    passport_number = models.CharField(max_length=20, blank=True, null=True)
    date_of_birth = models.DateField(blank=True, null=True)
    passpoet_issue_date = models.DateField(blank=True, null=True)
    passport_expiry_date = models.DateField(blank=True, null=True)
    passport_picture = models.ImageField(
        upload_to="media/passport_pictures", blank=True, null=True
    )
    country = models.CharField(max_length=50, blank=True, null=True)
    is_visa_included = models.BooleanField(default=False)
    is_ziyarat_included = models.BooleanField(default=False)
    is_food_included = models.BooleanField(default=False)
    visa_price = models.FloatField(default=0)
    is_family_head = models.BooleanField(default=False)
    family_number= models.IntegerField(default=0)
    shirka = models.ForeignKey(Shirka, on_delete=models.PROTECT, blank=True, null=True)
    visa_status = models.CharField(
        max_length=20, default="Pending"
    )  # e.g., Pending, Approved, Rejected
    ticket_status = models.CharField(
        max_length=20, default="Pending"
    )  # e.g., Pending, Confirmed, Cancelled
    ticket_remarks = models.TextField(blank=True, null=True)
    visa_group_number = models.CharField(max_length=20, blank=True, null=True)
    
    ticket_voucher_number = models.CharField(max_length=20, blank=True, null=True)
    ticker_brn= models.CharField(max_length=20, blank=True, null=True)
    food_voucher_number = models.CharField(max_length=20, blank=True, null=True)
    food_brn = models.CharField(max_length=20, blank=True, null=True)
    ziyarat_voucher_number = models.CharField(max_length=20, blank=True, null=True)
    ziyarat_brn = models.CharField(max_length=20, blank=True, null=True)
    transport_voucher_number = models.CharField(max_length=20, blank=True, null=True)
    transport_brn = models.CharField(max_length=20, blank=True, null=True)

class BookingPersonContactDetails(models.Model):
    person = models.ForeignKey(
        BookingPersonDetail, on_delete=models.CASCADE, related_name="contact_details"
    )
    phone_number = models.CharField(max_length=20, blank=True, null=True)
    remarks = models.TextField(blank=True, null=True)

class BookingPersonZiyaratDetails(models.Model):
    person = models.ForeignKey(
        BookingPersonDetail, on_delete=models.CASCADE, related_name="ziyarat_details"
    )
    city = models.CharField(max_length=50)
    date= models.DateField()
    price = models.FloatField(default=0)
    is_price_pkr= models.BooleanField(default=True)
    riyal_rate = models.FloatField(default=0)


class BookingPersonFoodDetails(models.Model):
    person = models.ForeignKey(
        BookingPersonDetail, on_delete=models.CASCADE, related_name="food_details"
    )
    food = models.CharField(max_length=50)
    price = models.FloatField(default=0)
    is_price_pkr= models.BooleanField(default=True)
    riyal_rate = models.FloatField(default=0)


class Payment(models.Model):
    organization = models.ForeignKey(
        Organization, on_delete=models.CASCADE, related_name="payments"
    )
    branch = models.ForeignKey(
        Branch, on_delete=models.CASCADE, related_name="payments"
    )
    agency = models.ForeignKey(
        Agency, on_delete=models.CASCADE, related_name="payments", blank=True, null=True
    )
    agent = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name="payments", blank=True, null=True
    )
    created_by = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="created_payments",
        blank=True,
        null=True,
    )
    booking = models.ForeignKey(
        Booking,
        on_delete=models.CASCADE,
        related_name="payment_details",
        blank=True,
        null=True,
    )
    method = models.CharField(max_length=50)
    bank = models.ForeignKey(
        Bank, on_delete=models.CASCADE, related_name="payments", blank=True, null=True
    )
    amount = models.FloatField(default=0)
    date = models.DateTimeField(auto_now_add=True)
    remarks = models.TextField(blank=True, null=True)
    status = models.CharField(
        max_length=20, default="Pending"
    )  # e.g., Pending, Completed, Failed
    image = models.ImageField(upload_to="media/payment_receipts", blank=True, null=True)
    transaction_number = models.CharField(max_length=100, blank=True, null=True)
