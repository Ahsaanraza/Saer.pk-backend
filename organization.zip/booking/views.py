from rest_framework import viewsets
from django.db.models import Prefetch, Sum, F, Value, DecimalField,FloatField
from django.db.models.functions import Coalesce, Round,Cast

from .models import (
    Booking,
    BookingHotelDetails,
    BookingTransportDetails,
    BookingTicketDetails,
    BookingTicketTicketTripDetails,
    BookingTicketStopoverDetails,
    BookingPersonDetail,
    Payment,
)
from .serializers import BookingSerializer, PaymentSerializer


class BookingViewSet(viewsets.ModelViewSet):
    serializer_class = BookingSerializer

    def get_queryset(self):
        """
        Optimized queryset to prevent N+1 queries using select_related and prefetch_related.
        """
        return (
            Booking.objects.annotate(
                paid_amount=Coalesce(
                    Sum("payment_details__amount", output_field=FloatField()),
                    Value(0.0, output_field=FloatField()),
                    output_field=FloatField(),
                ),
                remaining_amount=Cast(
                    Round(
                        Cast(F("total_amount"), FloatField()) - Coalesce(
                            Sum("payment_details__amount", output_field=FloatField()),
                            Value(0.0, output_field=FloatField()),
                            output_field=FloatField(),
                        ),
                        2  # round to 2 decimals
                    ),
                    FloatField()
                )
            )
            .prefetch_related(
                "hotel_details",
                "transport_details",
                Prefetch(
                    "ticket_details",
                    queryset=BookingTicketDetails.objects.prefetch_related(
                        "trip_details", "stopover_details"
                    ),
                ),
                "person_details",
                "payment_details",
            )
            .order_by("-date")
        )


class PaymentViewSet(viewsets.ModelViewSet):
    serializer_class = PaymentSerializer

    def get_queryset(self):
        return Payment.objects.select_related(
            "organization", "branch", "agency", "agent", "created_by", "booking", "bank"
        ).order_by("-date")
