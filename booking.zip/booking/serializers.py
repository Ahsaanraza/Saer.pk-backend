from rest_framework import serializers
from .models import (
    Booking,
    BookingHotelDetails,
    BookingTransportDetails,
    BookingTicketDetails,
    BookingTicketTicketTripDetails,
    BookingTicketStopoverDetails,
    BookingPersonZiyaratDetails,
    BookingPersonFoodDetails,
    BookingPersonDetail,
    BookingPersonContactDetails,
    Payment,
)
from django.db import transaction

# --- Child serializers ---


class BookingTicketTripDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = BookingTicketTicketTripDetails
        fields = "__all__"
        extra_kwargs = {"ticket": {"read_only": True}}


class BookingTicketStopoverDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = BookingTicketStopoverDetails
        fields = "__all__"
        extra_kwargs = {"ticket": {"read_only": True}}


class BookingTicketDetailsSerializer(serializers.ModelSerializer):
    trip_details = BookingTicketTripDetailsSerializer(many=True, required=False)
    stopover_details = BookingTicketStopoverDetailsSerializer(many=True, required=False)

    class Meta:
        model = BookingTicketDetails
        fields = "__all__"
        extra_kwargs = {"booking": {"read_only": True}}

    def create(self, validated_data):
        trip_data = validated_data.pop("trip_details", [])
        stopover_data = validated_data.pop("stopover_details", [])
        ticket = BookingTicketDetails.objects.create(**validated_data)

        if trip_data:
                BookingTicketTicketTripDetails.objects.bulk_create(
                    [
                        BookingTicketTicketTripDetails(
                            ticket=ticket,
                            departure_city=td["departure_city"],
                            arrival_city=td["arrival_city"],
                            departure_date_time=td["departure_date_time"],
                            arrival_date_time=td["arrival_date_time"],
                            trip_type=td["trip_type"],
                        )
                        for td in trip_data
                    ]
                )
      # Stopover Details
        if stopover_data:
            BookingTicketStopoverDetails.objects.bulk_create(
                [
                    BookingTicketStopoverDetails(
                        ticket=ticket,
                        stopover_city=sd["stopover_city"],
                        stopover_duration=sd["stopover_duration"],
                        trip_type=sd["trip_type"],
                    )
                    for sd in stopover_data
                ]
            )

        return ticket

    def update(self, instance, validated_data):
        trip_data = validated_data.pop("trip_details", [])
        stopover_data = validated_data.pop("stopover_details", [])

        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()


        if trip_data is not None:
            instance.trip_details.all().delete()
            BookingTicketTicketTripDetails.objects.bulk_create(
                [
                    BookingTicketTicketTripDetails(
                        ticket=instance,
                        departure_city=td["departure_city"],
                        arrival_city=td["arrival_city"],
                        departure_date_time=td["departure_date_time"],
                        arrival_date_time=td["arrival_date_time"],
                        trip_type=td["trip_type"],
                    )
                    for td in trip_data
                ]
            )
        if stopover_data is not None:
            instance.stopover_details.all().delete()
            BookingTicketStopoverDetails.objects.bulk_create(
                [
                    BookingTicketStopoverDetails(
                        ticket=instance,
                        stopover_city=sd["stopover_city"],
                        stopover_duration=sd["stopover_duration"],
                        trip_type=sd["trip_type"],
                    )
                    for sd in stopover_data
                ]
            )
        return instance


class BookingHotelDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = BookingHotelDetails
        fields = "__all__"
        extra_kwargs = {"booking": {"read_only": True}}


class BookingTransportDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = BookingTransportDetails
        fields = "__all__"
        extra_kwargs = {"booking": {"read_only": True}}


class BookingPersonZiyaratDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = BookingPersonZiyaratDetails
        fields = "__all__"
        extra_kwargs = {"person": {"read_only": True}}
class BookingPersonFoodDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = BookingPersonFoodDetails
        fields = "__all__"
        extra_kwargs = {"person": {"read_only": True}}
class BookingPersonContactDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = BookingPersonContactDetails
        fields = "__all__"
        extra_kwargs = {"person": {"read_only": True}}

class BookingPersonDetailSerializer(serializers.ModelSerializer):
    ziyarat_details = BookingPersonZiyaratDetailsSerializer(many=True, required=False)
    food_details = BookingPersonFoodDetailsSerializer(many=True, required=False)
    contact_details = BookingPersonContactDetailsSerializer(many=True, required=False)
    class Meta:
        model = BookingPersonDetail
        fields = "__all__"
        extra_kwargs = {"booking": {"read_only": True}}
    
    def create(self, validated_data):
        ziyarat_data = validated_data.pop("ziyarat_details", [])
        food_data = validated_data.pop("food_details", [])
        contact_data = validated_data.pop("contact_details", [])
        person = BookingPersonDetail.objects.create(**validated_data)

        if ziyarat_data:
            BookingPersonZiyaratDetails.objects.bulk_create(
                [BookingPersonZiyaratDetails(person=person, **zd) for zd in ziyarat_data]
            )
        if food_data:
            BookingPersonFoodDetails.objects.bulk_create(
                [BookingPersonFoodDetails(person=person, **fd) for fd in food_data]
            )
        if contact_data:
            BookingPersonContactDetails.objects.bulk_create(
                [BookingPersonContactDetails(person=person, **cd) for cd in contact_data]
            )
        return person
    
    def update(self, instance, validated_data):
        ziyarat_data = validated_data.pop("ziyarat_details", [])
        food_data = validated_data.pop("food_details", [])
        contact_data = validated_data.pop("contact_details", [])

        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()

        if ziyarat_data is not None:
            instance.ziyarat_details.all().delete()
            BookingPersonZiyaratDetails.objects.bulk_create(
                [BookingPersonZiyaratDetails(person=instance, **zd) for zd in ziyarat_data]
            )
        if food_data is not None:
            instance.food_details.all().delete()
            BookingPersonFoodDetails.objects.bulk_create(
                [BookingPersonFoodDetails(person=instance, **fd) for fd in food_data]
            )
        if contact_data is not None:
            instance.contact_details.all().delete()
            BookingPersonContactDetails.objects.bulk_create(
                [BookingPersonContactDetails(person=instance, **cd) for cd in contact_data]
            )
        return instance
    


class PaymentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Payment
        fields = "__all__"
        extra_kwargs = {"booking": {"read_only": True}}


# --- Main Booking Serializer ---
class BookingSerializer(serializers.ModelSerializer):
    hotel_details = BookingHotelDetailsSerializer(many=True, required=False)
    transport_details = BookingTransportDetailsSerializer(many=True, required=False)
    ticket_details = BookingTicketDetailsSerializer(many=True, required=False)
    person_details = BookingPersonDetailSerializer(many=True, required=False)
    payment_details = PaymentSerializer(many=True, required=False)
    remaining_amount = serializers.FloatField(read_only=True)

    class Meta:
        model = Booking
        fields = "__all__"

    @transaction.atomic
    def create(self, validated_data):
        hotel_data = validated_data.pop("hotel_details", [])
        transport_data = validated_data.pop("transport_details", [])
        ticket_data = validated_data.pop("ticket_details", [])
        person_data = validated_data.pop("person_details", [])
        payment_data = validated_data.pop("payment_details", [])

        booking = Booking.objects.create(**validated_data)

        # --- Flat relations (bulk_create) ---
        if hotel_data:
            BookingHotelDetails.objects.bulk_create(
                [BookingHotelDetails(booking=booking, **hd) for hd in hotel_data]
            )
        if transport_data:
            BookingTransportDetails.objects.bulk_create(
                [BookingTransportDetails(booking=booking, **td) for td in transport_data]
            )
    
        # --- Nested tickets (delegate to serializer) ---
        for td in ticket_data:
            serializer = BookingTicketDetailsSerializer()
            serializer.create({**td, "booking": booking})

        # --- Nested persons (delegate to serializer) ---
        for pd in person_data:
            serializer = BookingPersonDetailSerializer(data=pd)
            serializer.is_valid(raise_exception=True)
            serializer.save(booking=booking)

        # --- Flat payments ---
        if payment_data:
            Payment.objects.bulk_create(
                [Payment(booking=booking, **pay) for pay in payment_data]
            )

        return booking

    @transaction.atomic
    def update(self, instance, validated_data):
        hotel_data = validated_data.pop("hotel_details", [])
        transport_data = validated_data.pop("transport_details", [])
        ticket_data = validated_data.pop("ticket_details", [])
        person_data = validated_data.pop("person_details", [])
        payment_data = validated_data.pop("payment_details", [])

        # update booking fields
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()

        # --- Hotels ---
        if hotel_data is not None:
            instance.hotel_details.all().delete()
            BookingHotelDetails.objects.bulk_create(
                [BookingHotelDetails(booking=instance, **hd) for hd in hotel_data]
            )

        # --- Transport ---
        if transport_data is not None:
            instance.transport_details.all().delete()
            BookingTransportDetails.objects.bulk_create(
                [BookingTransportDetails(booking=instance, **td) for td in transport_data]
            )

        # --- Tickets ---
        if ticket_data is not None:
            instance.ticket_details.all().delete()
            for td in ticket_data:
                serializer = BookingTicketDetailsSerializer(data=td)
                serializer.is_valid(raise_exception=True)
                serializer.save(booking=instance)

        # --- Persons ---
        if person_data is not None:
            instance.person_details.all().delete()
            for pd in person_data:
                serializer = BookingPersonDetailSerializer(data=pd)
                serializer.is_valid(raise_exception=True)
                serializer.save(booking=instance)

        # --- Payments ---
        if payment_data is not None:
            instance.payment_details.all().delete()
            Payment.objects.bulk_create(
                [Payment(booking=instance, **pay) for pay in payment_data]
            )

        return instance



class PaymentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Payment
        fields = "__all__"