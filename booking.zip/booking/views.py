from rest_framework import viewsets,status
from django.db.models import Prefetch, Sum, F, Value, DecimalField,FloatField
from django.db.models.functions import Coalesce, Round,Cast

from .models import (
    Booking,
    BookingHotelDetails,
    BookingTransportDetails,
    BookingTicketDetails,
    BookingTicketTicketTripDetails,
    BookingTicketStopoverDetails,
    BookingPersonDetail,
    Payment,
)
from .serializers import BookingSerializer, PaymentSerializer
from rest_framework.parsers import MultiPartParser, FormParser, JSONParser
from rest_framework.response import Response

import json
class BookingViewSet(viewsets.ModelViewSet):
    serializer_class = BookingSerializer
    parser_classes = [MultiPartParser, FormParser, JSONParser]

    NESTED_FIELDS = [
        "ticket_details",
        "person_details",
        "hotel_details",
        "transport_details",
    ]
    def get_queryset(self):
        """
        Optimized queryset to prevent N+1 queries using select_related and prefetch_related.
        """
        return (
            Booking.objects.annotate(
                paid_amount=Coalesce(
                    Sum("payment_details__amount", output_field=FloatField()),
                    Value(0.0, output_field=FloatField()),
                    output_field=FloatField(),
                ),
                remaining_amount=Cast(
                    Round(
                        Cast(F("total_amount"), FloatField()) - Coalesce(
                            Sum("payment_details__amount", output_field=FloatField()),
                            Value(0.0, output_field=FloatField()),
                            output_field=FloatField(),
                        ),
                        2  # round to 2 decimals
                    ),
                    FloatField()
                )
            )
            .prefetch_related(
                "hotel_details",
                "transport_details",
                Prefetch(
                    "ticket_details",
                    queryset=BookingTicketDetails.objects.prefetch_related(
                        "trip_details", "stopover_details"
                    ),
                ),
                "person_details",
                "payment_details",
            )
            .order_by("-date")
        )


    def _parse_to_list(self, val):
        """Return a list of dicts from val (str JSON / dict / list) or [] on failure."""
        if isinstance(val, str):
            try:
                parsed = json.loads(val)
            except Exception:
                return []
        elif isinstance(val, dict):
            return [val]
        elif isinstance(val, list):
            parsed = val
        else:
            return []

        if isinstance(parsed, dict):
            return [parsed]
        if isinstance(parsed, list):
            return parsed
        return []

    def _normalize_data(self, request):
        """
        Convert request.data (QueryDict) → plain dict with proper nested Python lists/dicts.
        IMPORTANT: Do NOT return a QueryDict; return a normal dict.
        """
        raw = request.data
        out = {}

        # If it's a QueryDict, use get() for first item; else treat it like a normal dict
        is_qd = hasattr(raw, "getlist")

        for key in (raw.keys() if is_qd else raw):
            value = raw.get(key) if is_qd else raw.get(key)

            if key in self.NESTED_FIELDS:
                out[key] = self._parse_to_list(value)
            else:
                out[key] = value  # let serializer coerce scalars (ints/bools/dates)

        # Attach uploaded passport picture to the right person record
        persons = out.get("person_details")
        if isinstance(persons, list):
            for person in persons:
                if isinstance(person, dict) and "passport_picture_field" in person:
                    ref = person["passport_picture_field"]
                    file_key = f"person_files[{ref}]"
                    file_obj = request.FILES.get(file_key)
                    if file_obj:
                        person["passport_picture"] = file_obj

        return out


    def create(self, request, *args, **kwargs):
        normalized = self._normalize_data(request)
        serializer = self.get_serializer(data=normalized)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def update(self, request, *args, **kwargs):
        normalized = self._normalize_data(request.data)
        partial = kwargs.pop("partial", False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=normalized, partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        return Response(serializer.data)

class PaymentViewSet(viewsets.ModelViewSet):
    serializer_class = PaymentSerializer

    def get_queryset(self):
        return Payment.objects.select_related(
            "organization", "branch", "agency", "agent", "created_by", "booking", "bank"
        ).order_by("-date")
